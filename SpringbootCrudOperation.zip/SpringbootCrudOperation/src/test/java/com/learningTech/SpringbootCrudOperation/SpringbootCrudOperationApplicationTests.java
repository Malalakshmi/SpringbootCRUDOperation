package com.learningTech.SpringbootCrudOperation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCrudOperationApplicationTests {

	@Test
	void contextLoads() {
	}

}
